#include "mcc_generated_files/mcc.h"
#include "mcc_generated_files/i2c2_master.h"
#include <math.h>
#include "mcc_generated_files/examples/i2c2_master_example.h"

// Humidity Sensor  
#define Humidity_Slave 0x27
#define Humidity_Data 0x00

// Temperature Sensor
#define Temp_Sensor 0x135

// Defining ID so that we can separate the data sent over UART
typedef enum {
    Temp_ID = 1,
    Hum_ID = 2,
    Motor_ID = 3
} Sensor_Type;

// Volatile variables
volatile uint16_t raw_hum = 0, raw_temp = 0;

// Converts binary to a decimal number
float Binary_to_Decimal(uint16_t data) {
    float decimal = 0;
    for (int i = 0; i < 16; i++) {
        if (data & 1) {
            decimal += (1 << i);
        }
        data >>= 1; 
    }
    return decimal;
}

// Formats raw binary humidity to readable values using formula provided by data sheet
float Humidity_Format(uint16_t data) {
    return ((float)data / 330);
}

/* Prints data formatted properly over UART
void Send_Data(float data, Sensor_Type sensor) {
    char buffer[50]; // Ensure adequate size
    if (sensor == Temp_ID) {
        sprintf(buffer, "Temperature: %.3f", data);
    } else if (sensor == Hum_ID) {
        sprintf(buffer, "Humidity: %.3f%%", data);  // Corrected format
    } else if (sensor == Motor_ID) {
        sprintf(buffer, "Speed: %.3f", data);
    }
    printf("%s\n", buffer);
}

// Reads data
// Reads data
void Read_Data(void) {
    raw_temp = I2C2_Read2ByteRegister(Temp_Sensor, Temp_Sensor);
    raw_hum = I2C2_Read2ByteRegister(Humidity_Slave, Humidity_Data);
}
*/
void main(void) {
    SYSTEM_Initialize(); 
    I2C2_Initialize();
    UART1_Initialize();

    while (1) {
        raw_hum = I2C2_Read1ByteRegister(Humidity_Slave, Humidity_Data);
        raw_temp = I2C2_Read1ByteRegister(Temp_Sensor, Temp_Sensor);
        float hum = Humidity_Format(raw_hum);
        printf("Humidity: %.3f%%\n", hum);
        printf("Temperature: %.3f�C\n", raw_temp);    
        __delay_ms(1000);
    }
}
